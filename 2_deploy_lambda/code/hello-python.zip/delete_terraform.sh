#! /bin/bash

## destroy the built services using terraform
terraform destroy