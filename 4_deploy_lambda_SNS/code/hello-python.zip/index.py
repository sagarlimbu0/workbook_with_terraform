# def lambda_handler(event, context):
#     message = "Hello {} !".format(event['key'])

#     return { 'message': message}

import json

def lambda_handler(event, context):
    ## check for any records available
    if 'Records' in event:
        s3_event= event['Records'][0]['s3']
       
        ## extract bucket and object/filename
        bucket_name= s3_event['kafka-first-proj']
        object_key= s3_event['stock_market.json']
       
        ## check if the file is uploaded; if YES print information
        if object_key == 'stock_market.json':
            print(f"File {object_key} is uploaded into bucket {bucket_name}")
           
        else:
            print(f"Lambda function triggered, but uploaded file name different")

    return {
        "statusCode": 200,
        'body': json.dumps('Lambda Function executed sucessfully')
    }
   
## send notification
def send_sns_notification(message):
#    sns_topic_arn = 'your_sns_topic_arn'  # Replace with your SNS topic ARN

    sns_topic_arn= 'arn:aws:sns:us-west-1:398845475087:kafka_file_notify'
    sns_client = boto3.client('sns')
   
    message= "File with specified name uploaded"

    sns_client.publish(
        TopicArn=sns_topic_arn,
        Message=message,
        Subject='File Upload Notification'
    )