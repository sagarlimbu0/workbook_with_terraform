import os
import boto3

from flask import Flask, request, render_template, send_from_directory, url_for


## Note: To deploy the application via AWS ElasticBeanstalk, naming convention imporatant: `application`
# app= Flask(__name__)
application= Flask(__name__)

## Access file from S3 Bucket and use for visuailzation
'''
    - access the s3 bucket
    - filename should be static: `merra_2023`

'''

@application.route('/')
def home():
    return render_template("map.html")

@application.route('/About')
def about():
    return render_template("about.html")

# Render the worldmap file from specified dir.
@application.route("/get_world_map")
def get_world_map():
    # return send_from_directory('static/data', "world.geojson", as_attachment=True, mimetype='application/json')
    return send_from_directory('static/data', "ne_110m_ocean.geojson", as_attachment=True, mimetype='application/json')


## get the file from S3 Bucket


# Render the climate variable file from specified dir. in csv format
@application.route("/get_climate_data")
def get_oco2_data():
    filename= request.args.get('filename') + '.csv'
    return send_from_directory("static/data/climate", filename, as_attachment= True, mimetype= 'text/csv')

# Note: in production stage, remove the syntax for application.debug= True
if __name__ == "__main__":
    application.debug= True
    application.run()

