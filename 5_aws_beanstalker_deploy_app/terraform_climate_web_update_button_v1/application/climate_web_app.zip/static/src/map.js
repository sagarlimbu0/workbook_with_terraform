// Using D3 js to render the data from CSV in the map
// Main tools of d3 used in this web-app; D3 brush, scatter-plots, parallel(line) charts

// NOTE: There are several code sections whichare commented intentionally and not required to perform simple visualization; 
// This is ongoing project thus, there will incomplete or ongoing code scripts for testing purpose
// It is important to understand the FILE formats to display the data in the map. Currently, this code will use CSV format data. We can use different
//    file formats with js libraries


// SET the variables
var map_color = '#454545' //"#a9a9a9" //"#dfe6e6"
var circle_fill_color = "#c06c84"
var circle_stroke_color = "#6c5b7b"

var tooltip_offset = 1100 + 30;

// SVG to render the data points
// Select the SVG DOM from the `map.html`. 
// Document Object Model (DOM) is the data representation of the objects that comprise the structure and content of a document on the web.
var svg_map = d3.select("#map")
    .attr("viewBox", `350 -10 700 700`)

var width_map = window.innerWidth
var height_map = +svg_map.attr("height");
var margin2 = { top: 10, right: 10, bottom: 10, left: 0 };

// Set width and height
var width = window.innerWidth - margin2.left - margin2.right,
    height = +svg_map.attr("height");

// Set the variables to Offset the graphs to adjust the position in SVG
var leftOffset = 250;
// Adjust the WIDTH of the chart
var line_chart_width = 450;

// append the svg object to the body of the page
svg_map.append("g")
    .attr("transform", "translate(" + margin2.left + "," + margin2.top + ")");

// Using D3's map projection
var projection = d3.geoNaturalEarth1()
    //  var projection = d3.geoOrthograph/ic() //ortho spherical
    // .scale(width_map / Math.PI)
    .translate([width_map / 2, height_map / 2])
    .scale([200])
// .rotate([0, 0]);

const config = {
    speed: 0.010,
    verticalTilted: -10,
    horizontalTilted: 0
}

// Optional: Use the function to rotate the global map
// Rotate the global map
function Rotate() {
    d3.timer(function (elapsed) {
        projection.rotate(
            [
                config.speed * elapsed - 120,
                config.verticalTilted,
                config.horizontalTilted]);

        svg_map.selectAll("path").attr("d", path);

    })
}

///////////////////////////
//// TAB buttons
function showTab(tabId) {
    // Hide all tab contents
    var tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(function (tabContent) {
        tabContent.classList.remove('active');
    });

    // Deactivate all tabs
    var tabs = document.querySelectorAll('.tablinks');
    tabs.forEach(function (tab) {
        tab.classList.remove('active');
    });

    // Show the selected tab content and activate the corresponding tab
    document.getElementById(tabId).classList.add('active');
    event.currentTarget.classList.add('active');
}



/////////////////////
// Read the files
const selectInputFile = document.getElementById("climate_file")

//button
const calculateData = document.getElementById("select_file")

// console.log("Reading files: ", selectInputFile)


////////////////////////////////////////////////////
// UPLOAD file feature; allows to upload file and display 
//function to display the csv files
function readCSV(evt) {
    var f = evt.target.files[0];
    output = [];

    if (f) {
        var r = new FileReader();
        r.onload = function (e) {
            var contents = e.target.result;
            document.write("File Uploaded! <br />" + "name: " + f.name + "<br />" + "content: " + contents + "<br />" + "type: " + f.type + "<br />" + "size: " + f.size + " bytes <br />");

            var lines = contents.split("\n")
            for (var i = 0; i < lines.length; i++) {
                output.push("<tr><td>" + lines[i].split(",").join("</td><td>") + "</td></tr>");
            }
            output = "<table>" + output.join("") + "</table>";
            document.write(output);
        }
        r.readAsText(f);

        document.write(output);
    } else {
        alert("Failed to load file");
    }
}
//   document.getElementById('climate_file').addEventListener('change', readCSV);


// Optional; Zoom feature on the map
var zoom = d3.zoom()
    .scaleExtent([1, 8])
    .on("zoom", zoomed);

// Enable zoom feature and rotation; call the svg
//svg_map.call(zoom);

// DRAG the map
const sensitivity = 75
let path = d3.geoPath().projection(projection)

// ZOOM feature
function zoomed() {

    // transforming the other data points as well
    var transformed = d3.event.transform

    svg_map.selectAll("path")
        .attr("transform", d3.event.transform);

    svg_map.selectAll(".pin, .circle")
        .attr("transform", d3.event.transform)
        .attr("r", 1.5 / transformed.k);
}

// Using Endpoint to get the World shape file; this file will be rendered using D3's JSON function
// Endpoint created on `map.html` file
// Load external GeoJSON data to render the projection of global map
d3.json(base_url + "/get_world_map", function (data) {

    svg_map.append("g")

        .selectAll("path")
        .data(data.features)
        .enter()
        .append("path")
        .style("fill", "#7fcdff")
        .style("stroke", "black")
        .style("stroke-width", 0.15)
        .attr("d", d3.geoPath()
            .projection(projection)
        )


    /////////////////////
    // Year selection; this dropdown feature allow User to select the data by year
    // DropDown menu will redirect the PATH for file selection
    d3.select("select")
        .on("change", function (d) {

            // Get the value from the Dropdown option
            var selected = d3.select("#data_year")
                .node().value;

            // console.log("FILE PATH: ")
            // file_path = "city_weather_halve_" + selected
            file_path = "merra_" + selected

            updateFileByYear(file_path)

        }).node().value;

    // TIME format; based on the format, transform the dateTime variable
    // var time_format= "%Y-%m-%d";
    var time_format = "%m/%d/%Y";

    // This function will take the file as input and select the variables
    // Cast the data-variables to numeric values
    function updateFileByYear(file_path) {
        // Redirect the PATH to file by selected YEAR
        return d3.csv(base_url + "/get_climate_data?filename=" + file_path,

            function (d) {
                return {
                    // Select the desired variables from the file and return the data

                    x: +d.Longitude,
                    y: +d.Latitude,
                    groups: +d.Anomaly,
                    tqi: +d.TQI,
                    month: +d.Month,
                    day: +d.Day,
                    year: +d.Year,
                    time_steps: +d.Time_Steps,

                    // climate variables

                    sea_lv: +d.sea_level_pressure,
                    temp_10m: +d.temp_10m,
                    humidity: +d.humidity,
                    air_temp: +d.air_temp,
                    percipitation: +d.total_percipitation,
                    east_wind_250: +d.east_wind_250,
                    east_wind_850: +d.east_wind_850,
                    north_wind_250: +d.north_wind_250,
                    north_wind_50: +d.north_wind_50,
                    wind_shear: +d.wind_shear


                    // city: +d.City,
                    // temperature: +d.Temperature,
                    // humidity: +d.Humidity,
                    // cloudiness: +d.Cloudiness,
                    // wind: +d.Wind,
                }
            },

            // Select the returned data with variables
            function (data) {

                // Assign unique ID
                var graph_ID = "graphs_id";


                function removeData() {
                    svg_map.select(".pin").remove();
                    svg_map.select("g.brush_function").remove();
                    svg_map.select("g.anomalies_function").remove();


                    // svg_graph.selectAll("circle").remove();

                }

                //////////////////
                /// CLEAR button to clear everything
                // d3.select("#clearAll")
                //     .on("click", function () {
                //         d3.selectAll("g." + graph_ID).remove();

                //     })



                // console.log("Parsed Data: ")
                // console.log(data)
                /////////////////////////////////////
                /// Selection by MONTH
                // This function has been commented since the current FILE (CSV) has only `year` variable
                // This is sub-function which will select the data by specified months of the year
                // EG: if the File in CSV format will have both year and months

                function updateMap(data, month_sel) {

                    ///To refresh the previous graphs and remove previous data-points
                    /// update and clean the map
                    removeData();

                    ///filter the data by month and use for visualization
                    data = data.filter(d => {
                        return d.month === +month_sel;
                    })

                    /////////////////////////////////////
                    //// MASKS
                    // TIME-STEPS selection 
                    function updateTimeStep(data, time_step_selection) {

                        ///To refresh the previous graphs and remove previous data-points
                        /// update and clean the map
                        removeData();

                        // Filter the data by selected Time-steps (0, 1, 2)
                        data = data.filter(d => {
                            return d.time_steps === +time_step_selection;
                        })


                        // console.log("Time-steps Data: ")
                        // console.log(data)

                        function uniqueVal(arr) {
                            let output = arr.filter(function (v, i, self) {
                                return i === self.indexOf(v);
                            });
                            return output;
                        }


                        var color_time_steps = d3.scaleOrdinal()
                            .domain([0, 1, 2])
                            .range(["#440154ff", "#21908dff", "#fde725ff"])



                        // //////////////////////////
                        // //// Color the dots with unique Anomalies
                        // var anomalies_keys = data.columns
                        var anomalies_color = uniqueVal(data.map(d => d.groups))

                        var color_dotted_anomalies = d3.scaleOrdinal()
                            .domain(anomalies_color)
                            .range(d3.schemeSet1);

                        // var color_dotted_anomalies = d3.scaleOrdinal().domain(anomalies_color)
                        //     .range(d3.schemeSet3);


                        /////////////////////////////////////////////////

                        // UPDATE the charts
                        removeData();
                        //////////////////////////////////////////////////
                        // append the points on MAP
                        var pinsGroup = svg_map.selectAll(".pin")
                            .data(data)
                            .enter().append("circle")
                            .attr("class", "pin")
                            // .attr("cx", function(d) { return projection([d.Longitude, d.Latitude])[0]; })
                            // .attr("cy", function(d) { return projection([d.Longitude, d.Latitude])[1]; })
                            .attr("cx", function (d) { return projection([d.x, d.y])[0]; })
                            .attr("cy", function (d) { return projection([d.x, d.y])[1]; })
                            .attr("r", .5)
                            // .attr("fill", "#f05f00")

                            .attr("fill", function (d) {
                                return color_dotted_anomalies(d.groups)
                            })

                        //////////////////////////////                    
                        //////////////////////////////
                        // Optional: COLOR BAR
                        // Create a color bar gradient

                        const colorBar = svg_map.append("g")
                            //.attr("transform", `translate( ${width_map /4.5  }, ${ height_map/ 2 })`);
                            .attr("transform", `translate( ${width_map / 3.5}, ${height_map / 1.9})`);


                        var color_bar_width = 1000
                        var segmentWidth = 15;
                        var segmentHeight = 20;
                        var segments = 18;
                        var segmentColors = [];
                        var columns = data.columns
                        ///*********************************************************** */

                        ////////////////
                        // Brushable actions on XCO2 globally
                        // using the brush to retrieve data points and display on scatter plot
                        // BRUSHING tool
                        var brush = d3.brush()
                            .extent([[0, 0], [width_map, height_map]])
                            .on("brush", brushed)

                        // .on("Start brush", brushCircle)

                        svg_map.append("g")
                            .attr("class", "brush_function")
                            .call(brush);

                        /////////////////////////////////
                        //// GRAPH section; use SVGs to render the charts
                        // NEW SVG selection
                        var svg_graph = d3.select("#graph");

                        // // SECOND graph chart
                        var svg_second_graph = d3.select("#second_graph");


                        //////////////////////////////////////
                        //// FIRST chart
                        // SCATTER PLOT uses the Second SVG where first SVG was used for rendering global map;
                        // Since this is an ongoing project, there are many aspect of improvements that can be made with the functionalities
                        // Developer can further build reusable code; i.e. using different variables as parameters and calling the function for diff. variables


                        var x_group_offset = 80;
                        var scatter_plot = svg_graph.append("g")

                            .attr("class", "scatter_plot")
                            .attr("transform", `translate(${x_group_offset}, 60)`)

                        ////////////////////////
                        // Second scatter plot chart; side-by-side using other vars
                        var scatter_plot_second = svg_graph.append("g")
                            .attr("class", "scatter_plot_second")
                            // .attr("transform", "translate(560," + (60) + ")")
                            .attr("transform", `translate(${x_group_offset + 400}, 60)`)

                        //// THIRD scatterplot graph
                        var scatter_plot_third = svg_graph.append("g")
                            .attr("class", "scatter_plot_third")
                            .attr("transform", `translate(${x_group_offset + 800}, 60)`)

                        // LINE plot: modis
                        var line_graph = svg_graph.append("g")

                        //////////////////////
                        ///// parallel Chart; use third SVG
                        var parallel_graph = svg_second_graph.append("g")
                            .attr("transform", "translate(220," + 60 + ")")


                        /////////////////////
                        /// TABLE; Information on data-points selected from BRUSH func.
                        // var table_data_points = d3.select("#pixle_info tbody")
                        var table_data_points = svg_map.append("foreignObject")


                        //// TABLE with variables values
                        //var tableBody = d3.select("#data-table tbody")
                        // Create TABLE
                        var tableBody = d3.select("#data-table tbody")


                        //// LEGEND, selecting the MAP SVG; this svg is different than the CHART
                        // LEGEND labels
                        var legend_labels = svg_map.append("g").attr("class", "anomalies_function")
                        var legend_colors = svg_map.append("g").attr("class", "anomalies_function")
                        var legend_title = svg_map.append("g").attr("class", "anomalies_function")

                        // LEGEND labels for Parallel CHARTS
                        var legend_labels_second = svg_second_graph.append("g").attr("class", "anomalies_function")

                        // .attr("transform", "translate(580," + (300) + ")")
                        // var legend_colors_second = svg_second_graph.append("g").attr("class", "anomalies_function")
                        // var legend_title_second = svg_second_graph.append("g").attr("class", "anomalies_function")

                        var legend_colors_second = svg_second_graph.append("g")
                        var legend_title_second = svg_second_graph.append("g")

                        // Remove previous Data points from GRAPH
                        // function to CLEAR previous data points
                        function removeScatterPoints() {
                            //    scatter_plot.selectAll("circle").remove();
                            scatter_plot.selectAll("*").remove();
                            // scatter_plot_second.selectAll("*").remove();


                            scatter_plot_second.selectAll("*").remove();
                            scatter_plot_third.selectAll("*").remove();

                            // svg_map.select("g.anomalies_function").remove();

                            legend_colors.selectAll("rect").remove();

                            legend_labels.selectAll("*").remove();
                            legend_title.selectAll("*").remove();

                            // clear the second legend labels
                            legend_colors_second.selectAll("*").remove();
                            legend_labels_second.selectAll("*").remove();
                            legend_title_second.selectAll("*").remove();

                            // clear the second graph
                            parallel_graph.selectAll("*").remove();

                            line_graph.selectAll("*").remove();
                            tableBody.selectAll("*").remove();
                            // table.selectAll("*").remove();

                        }

                        /////////////////////////////////////
                        // Select the Anomaly drop-down option
                        const anomaly_first = document.getElementById("anomalies_selection")

                        // select the second anomaly
                        const anomaly_second = document.getElementById("anomalies_selection_second")


                        // select the third anomaly
                        const anomaly_third = document.getElementById("anomalies_selection_third")


                        // Drop-down options
                        var select_x_variable = d3.select("#select_var_x")
                        var select_y_variable = d3.select("#select_var_y")

                        // var select_x_variable = document.getElementById("select_var_x")
                        // var select_y_variable = document.getElementById("select_var_y")

                        /// For drop-down menus
                        /// Function to remove previous data-points

                        // Remove previous Data points from GRAPH
                        // function to CLEAR previous data points
                        function remove_drop_down_data() {
                            //    scatter_plot.selectAll("circle").remove();
                            //scatter_plot.selectAll("*").remove();

                            // scatter_plot_second.selectAll("*").remove();
                            scatter_plot_second.selectAll("text").remove();
                            scatter_plot_second.selectAll("g").remove();



                            // scatter_plot_third.selectAll("*").remove();


                            // clear the second graph
                            parallel_graph.selectAll("*").remove();

                            line_graph.selectAll("*").remove();
                            tableBody.selectAll("*").remove();
                            // table.selectAll("*").remove();

                            select_x_variable.property("selectIndex", 0);
                            select_y_variable.property("selectIndex", 0);

                            // select_x_variable.selectAll("*").remove();
                            // select_y_variable.selectAll("*").remove();

                        }

                        ///// Clear button
                        ///// Clear previous SVG elements

                        const clear_scatterplot_graph = document.getElementById("clear_button");

                        clear_scatterplot_graph.addEventListener("click", clear_scatterplot);

                        // function to clear drop-down x and y variables
                        function reset_x_y_vars() {
                            select_x_variable.property("value", "");
                            select_y_variable.property("value", "");
                        }

                        function clear_scatterplot() {
                            scatter_plot_second.selectAll("*").remove()

                            // anomaly_first.property("value","");
                            // anomaly_second.property("value","");
                            // anomaly_third.property("value","");

                            
                            // call the function from above
                            reset_x_y_vars();

                        }





                        // AUTO fills the number of anomalies with D3 brush tool
                        function anomaly_dropDown(anomaly_elements, select_button) {


                            // default value
                            select_button.innerHTML = "<option value='Anomaly'>Anomaly</option>"


                            // default value of the drop-down option
                            //iterate the options
                            anomaly_elements.forEach(value => {

                                const option = document.createElement("option");

                                option.text = +value;
                                select_button.add(option);
                            });


                            // Clear previous selection of variables
                            //select_x_variable.selectAll("option").remove()
                        }


                        /////////////////////////////////////////////
                        /////////////////////////////////////////////
                        /////////////////////////////////
                        // D3 Brush Feature to select the data-points
                        // selects the dotted points with BRUSH feature
                        function brushed() {
                            const selection = d3.event.selection;

                            removeScatterPoints();

                            if (selection) {

                                const selected_data_brush = data.filter(d => {
                                    const [x0, y0] = projection([d.x, d.y]);

                                    // Collect data within the SELECTED brush RANGE
                                    return x0 >= selection[0][0] && x0 <= selection[1][0] &&
                                        y0 >= selection[0][1] && y0 <= selection[1][1];
                                });

                                ///Do something with selectedPoints
                                // console.log("Selected Points:", selectedPoints)
                                /// testing with selected points


                                /////////////////////////////
                                //// LEGEND of Anomalies
                                function uniqueVal(arr) {
                                    let output = arr.filter(function (v, i, self) {
                                        return i === self.indexOf(v);
                                    });
                                    return output;
                                }


                                //////////////////////////
                                //// Legend Labels; Anomalies
                                // var anomalies_keys = data.columns
                                var anomalies_keys = uniqueVal(selected_data_brush.map(d => d.groups))

                                var size = 15;

                                var colorGroups = d3.scaleOrdinal()
                                    .domain(anomalies_keys)
                                    .range(d3.schemeSet1);


                                // var legend_colors = svg_map.append("g")
                                legend_colors.selectAll("mydots")

                                    // .attr("transform", "translate(0," + 200)
                                    .attr("transform", "translate(0," + (200) + ")")

                                    .data(anomalies_keys)
                                    .enter()
                                    .append("rect")
                                    .attr("x", 100)
                                    .attr("y", function (d, i) { return 100 + i * (size + 5) })
                                    .attr("width", size)
                                    .attr("height", size)
                                    // .style("fill", function (d) { return color_anomalies(d) })
                                    .style("fill", function (d) { return color_dotted_anomalies(d) })

                                // Add one dot in the legend for each name.
                                // var legend_labels= svg_map.append("g")
                                legend_labels.selectAll("mylabels")
                                    .attr("transform", "translate(0," + (800) + ")")
                                    .data(anomalies_keys)
                                    .enter()
                                    .append("text")
                                    .attr("x", 100 + size * 1.2)
                                    .attr("y", function (d, i) { return 100 + i * (size + 5) + (size / 2) }) // 100 is where the first dot appears. 25 is the distance between dots
                                    // .style("fill", function (d) { return color_anomalies(d) })

                                    .style("fill", function (d) { return color_dotted_anomalies(d) })

                                    .text(function (d) { return d })
                                    .attr("text-anchor", "left")
                                    .style("alignment-baseline", "middle")


                                //TITLE of legend; Anomalies
                                legend_title.append("text")
                                    .attr("y", 50)
                                    .attr("x", 100)
                                    .attr("dy", "2em")
                                    .style("text-anchor", "middle")
                                    .style("font-size", "15px")
                                    .text("Anomalies")




                                /////////////////////////////////////////
                                /////////// TABLE; caluclated values
                                // Dispaly the Values collected from BRUSH feature
                                // const tableBody = d3.select("#data-table tbody");


                                function create_table(anomaly_data, table_name) {

                                    const dataTable = d3.select(table_name)

                                    // console.log("filteredData: ", selectedPoints)
                                    // console.log(selectedPoints)

                                    // Calculate the values to display
                                    const unique_anomaly = d3.map(anomaly_data, function (d) { return d.groups }).keys(); // show the anomaly
                                    const totalCount = anomaly_data.length;
                                    const uniqueTimeSteps = Array.from(new Set(anomaly_data.map(d => d.time_steps))).join(", ");
                                    const mean_sea_level_pressure = d3.mean(anomaly_data, d => d.sea_lv);
                                    const mean_temp_10m = d3.mean(anomaly_data, d => d.temp_10m);
                                    const mean_percipitation = d3.mean(anomaly_data, d => d.percipitation);
                                    const mean_humidity = d3.mean(anomaly_data, d => d.humidity);


                                    // Update the text content of the placeholders
                                    d3.select("#Anomaly-placeholder").text(`Anomaly = ${unique_anomaly}`);
                                    d3.select("#total-pixels-placeholder").text(`Total Data Points = ${totalCount}`);
                                    d3.select("#time-steps-placeholder").text(`Time-Steps = ${uniqueTimeSteps}`);
                                    d3.select("#seal-level-pressure-placeholder").text(`Mean of Sea Level Pressure (SLP) = ${Math.round(mean_sea_level_pressure * 1000) / 1000}`);
                                    d3.select("#Temperature-10m-placeholder").text(`Mean of Temperature 10m (T10m)= ${Math.round(mean_temp_10m * 1000) / 1000}`);

                                    d3.select("#mean-percipitation-placeholder").text(`Mean of Total_Percipitation (TQV)= ${Math.round(mean_percipitation * 1000) / 1000}`);
                                    d3.select("#humidity-placeholder").text(`Mean of Humidity (Q850)= ${Math.round(mean_humidity * 1000) / 1000}`);


                                    // Hide the table unless the function triggers and display the table
                                    dataTable.attr("hidden", null);

                                }


                                ///////////////////////////////////////////
                                // drop-down menu
                                //Every time using d3 brush; new anomalies are selected which will be auto-filled on

                                const anomaly_keys = d3.map(selected_data_brush, function (d) { return d.groups }).keys()
                                // console.log("Anomalies selected: ", anomal)
                                anomaly_dropDown(anomaly_keys, anomaly_first)

                                //second anomaly
                                anomaly_dropDown(anomaly_keys, anomaly_second)

                                //third anomaly
                                anomaly_dropDown(anomaly_keys, anomaly_third)


                                ///////////////////////////////////////////
                                ////////////////////////////////////////////
                                // FILTER the data based on selected anomaly
                                // anomaly_first.addEventListener("change", filter_data_anomaly)

                                anomaly_first.addEventListener("change", function () {
                                    filter_data_anomaly(anomaly_first.value, "#FF5C5C")
                                })

                                // Second anomaly selection
                                //anomaly_second.addEventListener("change", filter_data_anomaly(anomaly_second.value))

                                anomaly_second.addEventListener("change", function () {
                                    filter_data_anomaly(anomaly_second.value, "#5C5CFF")
                                })


                                // Third anomaly selection
                                anomaly_third.addEventListener("change", function () {
                                    filter_data_anomaly(anomaly_third.value, "#52CC7A")
                                })

                                ////////////////////////////////
                                // Filter the Data by unique anomalies
                                function filter_data_anomaly(single_anomaly_value, color_scale) {
                                    const selected_anomaly = +single_anomaly_value

                                    //color of dotted-point
                                    var point_color = color_scale

                                    // Check if the anomaly value is passed
                                    //console.log("Single Anomaly: ", typeof selected_anomaly)

                                    //filter the data based on selected KEY
                                    // const new_filter_data= selectedPoints.filter(function(d){


                                    const selectedPoints = selected_data_brush.filter(function (d) {
                                        return +d.groups === +selected_anomaly
                                    })

                                    // Get the unique Anomaly value with drop-down menu
                                    const unique_key = +single_anomaly_value

                                    // console.log("Unique key: ", unique_key)

                                    // Create first table
                                    create_table(selectedPoints, "#data-table")

                                    // // Create second table
                                    // create_table(selectedPoints, "#data-table-second")





                                    // update the scatter plot graph
                                    //  removeScatterPoints();


                                    // window resize for graph
                                    var chart_width_adjust = 190;

                                    // SCATTER plot with the data within BRUSHED range
                                    var left_width = 40
                                    // var sep_chart= window.width + 242;

                                    var sep_chart = 1000;
                                    var xlabel_scale = "-.15em"
                                    var ylabel_scale = ".15em"

                                    /// Variables
                                    var firstVarSelection = "humidity"
                                    var secondVarSelection = "air_temp"
                                    var thirdVarSelection = "temp_10m"


                                    // Generate random color
                                    // function generateRandomData(numPoints) {
                                    //     return d3.range(numPoints).map(() => Math.floor(Math.random() * 10)); // Generate random numbers between 0 and 9
                                    // }



                                    // var color_range = generateRandomColors()

                                    // DEFAULT display of the x and y vars
                                    ///test the function

                                    updateScatterPlot(selectedPoints, unique_key, firstVarSelection, secondVarSelection, point_color)


                                    ///////////////////////////////
                                    // Drop-down selection feature
                                    // Event handler for the first dropdown
                                    // d3.select("#select_var_x")
                                    select_x_variable
                                        .on("change", function () {
                                            firstVarSelection = this.value; // Update the firstVarSelection

                                            // removeScatterPoints();
                                            // remove_drop_down_data();


                                            // clear previous svg elements
                                            // remove_drop_down_data();
                                            scatter_plot_second.selectAll("*").remove();

                                            updateScatterPlot(selectedPoints, unique_key, firstVarSelection, secondVarSelection, point_color);
                                        });

                                    // Event handler for the second dropdown
                                    //d3.select("#select_var_y")
                                    select_y_variable
                                        .on("change", function () {
                                            secondVarSelection = this.value; // Update the secondVarSelection

                                            // removeScatterPoints();
                                            //remove_drop_down_data();

                                            // clear previous svg elements
                                            // remove_drop_down_data();
                                            scatter_plot_second.selectAll("*").remove();

                                            updateScatterPlot(selectedPoints, unique_key, firstVarSelection, secondVarSelection, point_color);
                                        });


                                    //////////////////////////////////////////////
                                    // FUNCTION to update the SCATTER POINTS
                                    // function updateScatterPlot(filteredData, firstVar, secondVar, thirdVar) {
                                    function updateScatterPlot(filteredData, unique_key, firstVar, secondVar, color_selected) {

                                        // update the scatter plot graph
                                        // removeScatterPoints();
                                        remove_drop_down_data();


                                        // color of points
                                        // const colorScale = d3.scaleOrdinal()
                                        //     .domain(d3.range(10)) // Domain is numbers 0-9
                                        //     .range(d3.schemeCategory10);

                                        // Define list of colors
                                        //const colors = ['red', 'blue', 'green', 'orange', 'brown'];


                                        ////////////////////////////////
                                        /// Brush feature
                                        var scatter_brush = d3.brushX()
                                            .extent([[0, 0], [275, 200]])
                                            .on("end", updateChart)

                                        ////////////////////////////////
                                        /// function to collect the scatter-plot data
                                        function updateChart() {

                                            // Event Selection
                                            const selection = d3.event.selection;

                                            if (selection) {
                                                const selectedData = filteredData.filter(d => {
                                                    // const [x0, y0] = projection([d.x, d.y]);
                                                    const [x0, y0] = [d.x, d.y];

                                                    // Collect data within the SELECTED brush RANGE
                                                    return x0 >= selection[0][0] && x0 <= selection[1][0] &&
                                                        y0 >= selection[0][1] && y0 <= selection[1][1];
                                                });

                                                // console.log("Updated Data: ", selectedData)
                                            }
                                        }

                                        // Check the total selected data
                                        // var anomalies_keys = uniqueVal(filteredData.map(d => d.groups))

                                        // console.log("Selected Data: ", filteredData)
                                        // console.log("Keys: ", anomalies_keys)

                                        ///////////////////////////////
                                        /// Scatter-plot chart
                                        // for testing puprose; keeping middle chart 

                                        var height_adjust = 300;


                                        // Testing with filtered data and original data (data obtianed from brush)-> `selected_data_brush`

                                        var x_second_scatterplot = //d3.scaleTime()
                                            d3.scaleLinear()
                                                //.domain([0, 120]) // temp max: 120

                                                //.domain([d3.min(filteredData, d => d[firstVar]), d3.max(filteredData, d => d[firstVar])])
                                                .domain([d3.min(selected_data_brush, d => d[firstVar]), d3.max(selected_data_brush, d => d[firstVar])])
                                                .range([0, 450])//sep_chart/ 2])

                                        ////
                                        // .domain([273, 303])
                                        // .range([0, 275])//sep_chart/ 2])

                                        var y_second_scatterplot = d3.scaleLinear()
                                            //.domain([0, 60])
                                            // .domain([d3.min(filteredData, d => d[secondVar]), d3.max(filteredData, d => d[secondVar])])

                                            // using the data from brush selection
                                            .domain([d3.min(selected_data_brush, d => d[secondVar]), d3.max(selected_data_brush, d => d[secondVar])])
                                            .range([height_adjust, 0])

                                        // .domain([215, 253])
                                        // .range([200, 0])

                                        // X-AXIS 
                                        scatter_plot_second.append("g")
                                            //.attr("transform", "translate(0," + (height_map / 3.5) + ")")
                                            .attr("transform", "translate(0," + (height_adjust) + ")")
                                            .call(d3.axisBottom(x_second_scatterplot))
                                        // .selectAll("text")
                                        // .attr("transform", "rotate(75)")

                                        // Y-AXIS
                                        scatter_plot_second.append("g")
                                            // .attr("transform", "translate(800, 500 )")
                                            .call(d3.axisLeft(y_second_scatterplot))


                                        scatter_plot_second
                                            .selectAll("dot")
                                            .data(filteredData)
                                            .enter()
                                            .append("circle")
                                            // .attr("class", "scatter_plot")
                                            .attr("cx", function (d) { return x_second_scatterplot(d[firstVar]) })
                                            .attr("cy", function (d) { return y_second_scatterplot(d[secondVar]) })
                                            .attr("r", 4)
                                            // .style("opacity", .35)
                                            // .attr("fill", "red")
                                            // .attr("fill", (_, i) => colorScale(i))

                                            .style("fill", color_selected)
                                            //.attr("stroke", "black")


                                        // X-Axis label
                                        scatter_plot_second.append("text")
                                            .attr("transform", "translate(250," + (height_adjust + 40) + ")")
                                            .attr("text-anchor", "end")
                                            .text(firstVar)

                                        /// ADD Y-axis label
                                        scatter_plot_second.append("text")
                                            .attr("transform", "rotate(-90)")
                                            .attr("y", -95)
                                            .attr("x", -90)
                                            .attr("dy", "2.5em")
                                            .style("text-anchor", "middle")
                                            .text(secondVar)
                                        // .text("OCO2-XCO2")




                                        ////////////////////////////////////////
                                        ////////////////////////////////////////
                                        /// PARALLEL-GRAPH; multiple line charts
                                        /// Taking averages of the data-points and creating line-charts


                                        // console.log("Filtered Data")
                                        // console.log(filteredData)

                                        // const averages_total = Object.entries(
                                        //     filteredData.reduce((acc,
                                        //         { groups, temp_10m, air_temp, humidity, sea_lv }) => ({
                                        //             ...acc, [groups]: [...(acc[groups] || []),
                                        //             { temp_10m, air_temp, humidity, sea_lv }]
                                        //         }), {}))
                                        //     .map(([groups, dataPoints]) => {
                                        //         const average = dataPoints.reduce((acc,
                                        //             { temp_10m, air_temp, humidity, sea_lv }) =>
                                        //         ({
                                        //             temp_10m: acc.temp_10m + temp_10m,
                                        //             air_temp: acc.air_temp + air_temp,
                                        //             humidity: acc.humidity + humidity,
                                        //             sea_lv: acc.sea_lv + sea_lv,
                                        //         }),
                                        //             { temp_10m: 0, air_temp: 0, humidity: 0, sea_lv: 0 });

                                        //         const count = dataPoints.length;

                                        //         return {
                                        //             groups,
                                        //             temp_10m: average.temp_10m / count,
                                        //             air_temp: average.air_temp / count,
                                        //             humidity: average.humidity / count,
                                        //             sea_lv: average.sea_lv / count,
                                        //         };
                                        //     });


                                        // // multiple y-axis variables to show connection
                                        // // var climate_var = ["temperature", "humidity", "cloudiness", "wind"]

                                        // var climate_var = ["temp_10m", "humidity", "air_temp", "sea_lv"]

                                        // var color_climate = d3.scaleOrdinal()
                                        //     .domain([climate_var])
                                        //     .range(d3.schemeSet1);
                                        // //.range(["#440154ff", "#21908dff", "#fde725ff"])


                                        // var offSet = 5;

                                        // // Y-Axis variables for climate variables
                                        // // Multiple y-axis 
                                        // var y_b = {}
                                        // for (i in climate_var) {
                                        //     //// save all the climate variables
                                        //     name_ = climate_var[i]

                                        //     // console.log("variable name:")
                                        //     // console.log(climate_var[i])

                                        //     y_b[name_] = d3.scaleLinear()
                                        //         // .domain([0, 120])
                                        //         // .domain([d3.min(filteredData, d=> d[String(climate_var[i])], d3.max(filteredData, d=> d[String(climate_var[i])]))])

                                        //         // .domain([(d3.min(filteredData, d => d[String(climate_var[i])]) - offSet),
                                        //         // (d3.max(filteredData, d => d[String(climate_var[i])]) + offSet)])


                                        //         .domain([(d3.min(averages_total, d => d[String(climate_var[i])]) - offSet),
                                        //         (d3.max(averages_total, d => d[String(climate_var[i])]) + offSet)])

                                        //         // different AXIS for each climate var
                                        //         .range([height_map / 1.5, 0])
                                        // }

                                        // // console.log("list of y:")
                                        // // console.log(y_b)

                                        // // Build x-axis points for every climate var
                                        // var x_b = d3.scalePoint()
                                        //     .range([0, width / 1.65])
                                        //     .domain(climate_var)


                                        // // Function; PATH, to take a row of CSV as input
                                        // // Returns the x and y coordinate
                                        // function path_(d) {
                                        //     return d3.line()(climate_var.map(function (p) {
                                        //         return [x_b(p), y_b[p](d[p])];
                                        //     }));
                                        // }

                                        // // Draw the LINE plots
                                        // parallel_graph.selectAll("myPath")

                                        //     // .data(filteredData)

                                        //     .data(averages_total)
                                        //     .enter()
                                        //     .append("path")
                                        //     .attr("class", function (d) {
                                        //         return "line" + d.groups
                                        //     })
                                        //     .attr("d", path_)
                                        //     .attr("fill", "None")
                                        //     .style("stroke", function (d) {
                                        //         // return (color_climate(d.groups))
                                        //         return (colorGroups(d.groups))
                                        //     })
                                        //     .style("opacity", 1.5)
                                        // // .on("mouseover", highlight)
                                        // // .on("mouseleave", doNotHighlight)


                                        // /// Draw the AXIS
                                        // parallel_graph.selectAll("myAxis")
                                        //     .data(climate_var)
                                        //     .enter()
                                        //     .append("g")
                                        //     .attr("class", "axis")
                                        //     .attr("transform", function (d) {
                                        //         return "translate(" + x_b(d) + ")";
                                        //     })
                                        //     .each(function (d) {
                                        //         d3.select(this).call(d3.axisLeft()
                                        //             .ticks(5).scale(y_b[d]));
                                        //     })
                                        //     //add the title
                                        //     .append("text")
                                        //     .style("text-anchor", "middle")
                                        //     .attr("y", -9)
                                        //     .text(function (d) { return d; })
                                        //     .style("fill", "black")


                                        // /// LEGEND labels
                                        // // var legend_colors = svg_map.append("g")
                                        // legend_colors_second.selectAll("mydots")
                                        //     // .attr("transform", "translate(580," + (300) + ")")

                                        //     .data(anomalies_keys)
                                        //     .enter()
                                        //     .append("rect")
                                        //     .attr("x", 100)
                                        //     .attr("y", function (d, i) { return 100 + i * (size + 5) })
                                        //     .attr("width", size)
                                        //     .attr("height", size)
                                        //     // .style("fill", function (d) { return color_anomalies(d) })
                                        //     // .style("fill", function (d) { return colorGroups(d) })
                                        //     .style("fill", function (d) { return color_dotted_anomalies(d) })


                                        // // Add one dot in the legend for each name.
                                        // // var legend_labels= svg_map.append("g")
                                        // legend_labels_second.selectAll("mylabels")
                                        //     // .attr("transform", "translate(580," + (300) + ")")
                                        //     .data(anomalies_keys)
                                        //     .enter()
                                        //     .append("text")
                                        //     .attr("x", 100 + size * 1.2)
                                        //     .attr("y", function (d, i) { return 100 + i * (size + 5) + (size / 2) }) // 100 is where the first dot appears. 25 is the distance between dots
                                        //     // .style("fill", function (d) { return color_anomalies(d) })

                                        //     //.style("fill", function (d) { return colorGroups(d) })
                                        //     .style("fill", function (d) { return color_dotted_anomalies(d) })

                                        //     .text(function (d) { return d })
                                        //     .attr("text-anchor", "left")
                                        //     .style("alignment-baseline", "middle")


                                        // //TITLE of legend; Anomalies
                                        // legend_title_second.append("text")
                                        //     //.attr("transform", "translate(0," + 800)
                                        //     //.attr("class", "scatter_plot")
                                        //     // .attr("transform", "rotate(-90)")
                                        //     .attr("y", 50)
                                        //     .attr("x", 100)
                                        //     .attr("dy", "2em")
                                        //     .style("text-anchor", "middle")
                                        //     .style("font-size", "13px")
                                        //     .text("Agg. Values by Anomalies")



                                    }/// FUNCTION END for selecting scatterplot Vars

                                } /// Brush selection ending


                            }   /// FILTERING data by unique Anomaly drop-down option
                        }


                    }///// END of Time-steps; Toggle switch



                    ////////////////////////////////////
                    ////////////////////////////////////
                    ///toggle-switch for Time-STEPS

                    d3.select("#custom-toggle").on("change", function (d) {

                        //Time-steps selection by toggle switch
                        var selected_time_step = d3.select(this).property("value")

                        /// TEST

                        // console.log("Time-STEP selected: ",selected_time_step);

                        updateTimeStep(data, selected_time_step)

                    })

                    // default time-step; current time; `t`-> 1
                    // updateTimeStep(data, "1")

                    updateTimeStep(data, 1)




                } // END tag of MONTH selection function

                /////////////////////////////////////
                /// SLIDER feature; Alternative feature to add slider function for different month selection
                // /// UPDATE the map by month

                // var slider = document.getElementById("mySlider");
                // var output = document.getElementById("slider-value");

                // //// display the slider value
                // //output.innerHTML= slider.value;

                // //update the slider value when dragging
                // slider.oninput = function () {
                //     // output.innerHTML = this.value;
                //     var month = this.value;

                //     updateMap(data, month);

                //     ///update the scatter points
                //     //removeScatterPoints();
                //     //removeData();

                // }


                // MONTH dropdown function
                d3.select("#data_month")
                    .on("change", function (d) {

                        // Get the value from the Dropdown option
                        var selected_month = d3.select(this).property("value")


                        // console.log("Time-STEPS selected: ", selected_month)
                        // update with new dropdown values

                        updateMap(data, selected_month)

                    }).node().value;


                /// Default value for month selection
                updateMap(data, "1")
                // updateMap(data, 1)

            }
        )
    }
})


