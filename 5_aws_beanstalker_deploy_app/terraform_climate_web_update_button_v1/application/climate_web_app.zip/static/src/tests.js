// NOTE: These are tests to generate graphs and plots for the map
/// To generate multiple scatter plot graphs
// Based on passed off-set the graphs will be positioned on SVG

function create_scatter_plot(svg_id, data, firstVar, secondVar,
    x_off_group, y_off_group, x_offset, y_offset) {

    var chart_width_adjust = 190;


    //var x_off_group = 100 // first x= 100, then gap between graphs of 430
    //var y_off_group = 60 // y- level remains same
    // var x_offset= 0 
    // var y_offset= 200
    // Takes grouping as unique `g` which will be assign with x and y var
    // We will adjust the position by x and y scale


    // Assign the group
    var group = svg_id.append("g")
        .attr("transform", `translate(${x_off_group}, ${y_off_group} )`)

    // Assign x and y variable
    var x = d3.scaleLinear()
        .domain([0, 100])
        .range([0, 300])

    var y = d3.scaleLinear()
        .domain([0, 60])
        .range(0, 300)

    // Asign the grouping 
    // X-AXIS 
    group.append("g")
        // .attr("transform", "translate(0," + (200) + ")")
        .attr("transform", `translate(${x_offset}, ${y_offset})`)
        .call(d3.axisBottom(x)
            .tickSize(1.3)
            .ticks(10)
        )
        .selectAll("text")


    group.append("g")
        .call(d3.axisLeft(y))

    // SCATTER plot
    group
        .selectAll("dot")
        .data(data)
        .enter()
        .append("circle")
        // .attr("class", "scatter_plot")
        .attr("cx", function (d) { return x(d[firstVar]) })
        .attr("cy", function (d) { return y(d[secondVar]) })
        .attr("r", 3)
        .style("opacity", .5)
        .attr("fill", "green")
        .attr("stroke", "black")


    /// ADD Y-axis label
    group.append("text")
        .attr("transform", "rotate(-90)")
        .attr("y", -95)
        .attr("x", -70)
        .attr("dy", "2.5em")
        .style("text-anchor", "middle")
        .text(secondVar)
    // .text("OCO2-XCO2")

    // X-Axis label
    group.append("text")
        .attr("transform", "translate(160," + (chart_width_adjust + 55) + ")")
        .attr("text-anchor", "end")
        .text(firstVar)

}

////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
// TESTING: tooltips
// tooltip
         // Show information on hover
         pinsGroup.on("mouseover", function(d) {
            var screen_width = window.innerWidth;
            var mouse_left = d3.event.pageX;
            if (mouse_left > screen_width-300) {
                mouse_left = mouse_left - 300;
            }

            var tooltip = d3.select("#tooltip")
                .style("left", (mouse_left + 10) + "px")
                .style("top", (d3.event.pageY - tooltip_offset) + "px");

            tooltip.select("#xco2").text(d.mean_xco2)
                 
            // tooltip.select("#Longitude").text(d.Longitude)
            // tooltip.select("#Latitude").text(d.Latitude);
            tooltip.select("#Longitude").text(d.x)
            tooltip.select("#Latitude").text(d.y);
            
            // tooltip.select("#details").text("Site Classification: "+d.SITE_CLASSIFICATION);

            tooltip.style("display", "block");
        })


    /// BURSH functin to retrieve data as ARRAY 
           // // function to updated when called
       // function updateChart(svg){

       //     let value= [];

       //     // coordinates of the brush
       //     var selection = d3.event.selection;
           
           
       //     // if (!selection) { return }
           
       //     if (selection !== null ){
           
       //         let targetX1 = selection[0][0];
       //         let targetY1= selection[0][1];
       //         let targetX2= selection[1][0];
       //         let targetY2= selection[1][1];

       //         // get the array of circles
       //         const circles= d3.selectAll(".pin")
       //             .nodes();

       //         circles.forEach( element => {

       //             curr_x= element.cx.baseVal.value;
       //             curr_y= element.cy.baseVal.value;

       //         // see if node is in BRUSH rect.
       //         if (curr_x >= targetX1 && targetX2 &&
       //             curr_y >= targetY1 && curr_y <= targetY2){

       //                 toggleSelection( element.id);
       //             }
       //         });
               
       //     }
       //     }