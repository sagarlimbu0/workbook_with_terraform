import os
import boto3
import io
import json
import pandas as pd

# client
# client= boto3.client()

## S3 resource
s3 = boto3.resource('s3')

bucket_name= "merra-project"
file_name = "merra_2023.csv"

## path to bucket name and file
save_file_name = "downloaded_merra.csv"
s3.Bucket(bucket_name).download_file(file_name, save_file_name)

df= pd.read_csv(save_file_name)

print(df)
# new_dict= json.loads(data.getvalue().decode("utf-8"))
# print(new_dict)

